const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const cors = require('cors');
var ObjectId = require('mongoose').Types.ObjectId;
const GridFsStorage = require('multer-gridfs-storage');
//const Grid = require('gridfs-stream');
const axios = require('axios');
var fs = require("fs"), PDFParser = require("pdf2json");
var util = require('util');
//const mongoURI = 'mongodb://localhost:27017/VendorEmpPayDet';
//const conn = mongoose.createConnection(mongoURI);
let gfs;

//var { PFEmpData } = require('./models/employee');
//const { mongoose } = require('./db.js');
//var employeeController = require('./controllers/employeeController.js');

var app = express();
/* app.use(bodyParser.urlencoded({
    extended: true
 })); */
app.use(bodyParser.json());
//app.use(cors({ origin: 'http://localhost:4200' }));

app.listen(5000, () => console.log('Server started at port : 5000'));

var diskStorage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "./uploads");
    },
    filename: function (req, file, callback) {
        callback(null, file.originalname);
    }
});

var diskUpload = multer({ storage: diskStorage }).array("docUploader", 1);

app.get("/api/vendorUpload", function (req, res) {
    res.sendFile(__dirname + "/index.html");
});

app.post("/api/salaryUpload", async (req,res) => {
    diskUpload(req, res, function (err) {
    if (err) {
        return res.end("Something went wrong!");
    }
    console.log("OriginalName::::",req.files[0].originalname);
    res.send("Uploaded successfully");
}
)
});

app.get("/api/readSalaryDoc", function (req, res)  {
    vendorId = req.query.vendorId;
    month = req.query.month;
    
    var salary = {
        emp : []
    } ;
    salaryDoc = vendorId+"_"+month+"_2019.pdf";
    console.log(salaryDoc);
    let pdfParser = new PDFParser(this,1);
    pdfParser.on("pdfParser_dataError", errData => console.error(errData.parserError) );
    pdfParser.on("pdfParser_dataReady", pdfData => {
     var data = pdfParser.getRawTextContent().split("\r\n");
     console.log(data);
     salary.vendorName = data[0];
     salary.vendorId = data[0];
     salary.month = data[3].substr(data[3].indexOf("Month")+6,data[3].indexOf("Year")-7).trim();
     salary.year = data[3].substr(data[3].indexOf("Year")+4, data[3].length).trim();
     console.log(salary);
     let i = 17;
     console.log(data[i]);
     while(!data[i].includes("Total")){
        var empData = data[i].split(" ");
        salary.emp.push({"empid":empData[0],"empName":empData[1],"gross":empData[2],"uan":empData[3],"pfDetected":empData[4],"ipNumber":empData[5],"esiDetected":empData[6]});
        i++;
    }
    console.log("empDetails",salary.emp);
    res.send(salary);
   });
    pdfParser.loadPDF("./uploads/"+salaryDoc);
    
});



app.use('/api/getComplianceDetails', async function(req, res) {  
    var url = 'http://localhost:2000/api/getPFVendorEmpMonthDetails?establishmentId='+req.query.establishmentId+'&wageMonth='+req.query.wageMonth;
    var url2 = 'http://localhost:3000/api/getVendorEmpMonthList?vendorId='+req.query.establishmentId+'&month='+req.query.wageMonth;
    //var url3 = 'http://localhost:5000/api/readSalaryDoc?vendorId='+req.query.establishmentId+'&month='+req.query.wageMonth;
    //res.setHeader('content-type', 'application/json');
    //res.setHeader('From','tatasteel');
    var responseOne =  await CallPFSystem(url);
    
    var responseTwo = await CallTSSystem(url2);
    //var responseThree = CallSalarySystem(url3);
    var salary = {
        emp:[]
    } ;
    salaryDoc = req.query.establishmentId+"_"+req.query.wageMonth.toUpperCase()+"_2019.pdf";
    console.log(salaryDoc);
   let pdfParser = new PDFParser(this,1);
   pdfParser.on("pdfParser_dataError", errData => console.error(errData.parserError) );
   pdfParser.on("pdfParser_dataReady", pdfData => {
    var data = pdfParser.getRawTextContent().split("\r\n");
    //console.log(data);
    salary.vendorName = data[0];
    salary.vendorId = data[0];
    salary.month = data[3].substr(data[3].indexOf("Month")+6,data[3].indexOf("Year")-7).trim();
    salary.year = data[3].substr(data[3].indexOf("Year")+4, data[3].length).trim();
    //console.log(salary);
    let i = 17;
    //console.log(data[i]);
    let employee = [];
    console.log("TEst:"+responseOne.memberDetails[0].UAN);
    //console.log("UAN:UAN",JSON.parse(responseOne.memberDetails[0].uan));
    while(!data[i].includes("Total")){
        var empData = data[i].split(" ");
        for(var ts=0;ts<responseOne.memberDetails.length;ts++){
            if(responseOne.memberDetails[ts].UAN == empData[3]){
                salary.emp.push({"empid":empData[0],"empName":empData[1],"gross":empData[2],"uan":empData[3],"pfDetected":empData[4],"ipNumber":empData[5],"esiDetected":empData[6]});
            }
        } 
        i++;
    }
    console.log("empDetails",salary.emp);
    //res.send(responseOne.toString() + responseTwo.toString() + JSON.stringify(salary));
    //var parsedJson = JSON.parse(responseOne.memberDetails);
    //console.log(parsedJson);
    //console.log(responseOne.memberDetails);
  //console.log(responseTwo.memberDetail.UAN);
  //console.log(salary.emp);
    //console.log(k, k.length);
    var pfDetails = JSON.stringify(responseOne.memberDetails);
    console.log("PFDetails:"+ pfDetails);
    var tsDetails = JSON.stringify(responseTwo.vendorEmpDetails);
    console.log("TSDetails:"+ tsDetails);
    var salaryDetails = JSON.stringify(salary.emp);
    console.log("SalaryDetails:"+ salaryDetails);
    res.send("success");

   });
    pdfParser.loadPDF("./uploads/"+salaryDoc);
    
    
  });


  function CallPFSystem(url1) {
    return new Promise(async function (resolve, reject) {
        try {
            console.log(url1);
            var url = url1;
            var updateResult;
               await axios.get(url, {
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'From': 'tatasteel'                        
                        },
                    }).then(function (response) {
                        //console.log("Response:"+ util.inspect(response.data.toString()));
                        //updateResult = JSON.stringify(util.inspect(response.data));
                        updateResult = response.data;
                        console.log("URL1",updateResult.memberDetails[0].UAN);
                        //console.log("UAN:::::",response.data[0].memberDetails[0].UAN);
                    })
                    .catch(function (error) {
                        console.log(error);
                    });                
            resolve(updateResult);
        } catch (err) {
            console.log(err)
        } finally {}
    }).catch((err) => {
        console.log(err)
    });
}

function CallTSSystem(url2) {
    return new Promise(async function (resolve, reject) {
        try {
            console.log(url2);
            var url = url2;
            var updateResult;
               await axios.get(url, {
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                           // 'From': 'tatasteel'                        
                        },
                    }).then(function (response) {
                        console.log("Response:"+ util.inspect(response.data.toString()));
                        updateResult = response.data;
                        //console.log(response.data[0].memberDetails[0].UAN);
                    })
                    .catch(function (error) {
                        console.log(error);
                    });                
            resolve(updateResult);
        } catch (err) {
            console.log(err)
        } finally {}
    }).catch((err) => {
        console.log(err)
    });
}

function CallSalarySystem(url3) {
    return new Promise(async function (resolve, reject) {
        try {
            console.log(url3);
            var url = url3;
            var updateResult;
               await axios.get(url, {
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                           // 'From': 'tatasteel'                        
                        },
                    }).then(function (response) {
                        console.log("Response:"+ util.inspect(response.data.toString()));
                        updateResult = JSON.stringify(util.inspect(response.data));
                        //console.log(response.data[0].memberDetails[0].UAN);
                    })
                    .catch(function (error) {
                        console.log(error);
                    });                
            resolve(updateResult);
        } catch (err) {
            console.log(err)
        } finally {}
    }).catch((err) => {
        console.log(err)
    });
}
